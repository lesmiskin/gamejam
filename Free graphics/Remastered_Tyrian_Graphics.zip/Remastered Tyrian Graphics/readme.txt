"Remastered Tyrian Graphics" art by Daniel Cook (Lostgarden.com)

Originally downloaded from http://www.lostgarden.com/2007/04/free-game-graphics-tyrian-ships-and.html

Also available at http://opengameart.org/remastered-tyrian-graphics

Licensed under CC-By 3.0 (https://creativecommons.org/licenses/by/3.0/us/)